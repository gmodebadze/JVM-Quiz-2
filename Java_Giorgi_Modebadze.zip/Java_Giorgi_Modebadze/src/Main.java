import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {



        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Parent parent = FXMLLoader.load(getClass().getResource("view.fxml"));
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.show();
    }

}
//ამას აერორებს დაამიტომ ასე დავტოვებ
//    @Override
//    public void start(Stage stage) throws Exception {
//        // Create the pie chart
//        PieChart pieChart = new PieChart();
//
//        // Add data to the pie chart
//        pieChart.getData().add(new PieChart.Data("Fish", 10));
//        pieChart.getData().add(new PieChart.Data("Bread", 20));
//
//        // Create the scene and set the chart as its root
//        Scene scene = new Scene(pieChart, 400, 300);
//
//        // Set the scene on the stage and show it
//        stage.setScene(scene);
//        stage.show();
//    }
