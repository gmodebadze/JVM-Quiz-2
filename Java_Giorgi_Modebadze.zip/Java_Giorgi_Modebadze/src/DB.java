import java.sql.*;

public class DB {
    Connection connection;
    public DB() throws SQLException {
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "");
    }

    public ResultSet select() throws SQLException {
        ResultSet result = null;
        String sql = "SELECT * FROM person";
        Statement statement = connection.createStatement();
        result = statement.executeQuery(sql);
        return   result;
    }
}
