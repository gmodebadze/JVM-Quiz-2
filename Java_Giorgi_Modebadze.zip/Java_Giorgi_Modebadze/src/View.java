import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class View {
    Connection connection;
    @FXML
    TextField textfield;

    @FXML
    TextField textfield1;

    @FXML
    private TableView<?> table_view;





    public View() throws SQLException {
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "");
    }


    public int save_btn(){

        String text1 = textfield.getText();
        String text2 = textfield1.getText();
        String sql = String.format("INSERT INTO person(name,quantity) VALUES ('%s','%s')", text1,text2);

        Statement statement = null;
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int result = 0;
        try {
            result = statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }


}


